package studentRegisteration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentmanagement.persistant.dao.UserDAO;
import studentmanagement.persistant.dto.UserRequestDTO;

/**
 * Servlet implementation class UserDeleteController
 */
@WebServlet("/UserDeleteController")
public class UserDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserDeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userID=request.getParameter("userId");		
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserId(userID);
		UserDAO userdao=new UserDAO();
		int i=userdao.deleteUser(dto);
		if(i>0) {
			request.getRequestDispatcher("USR003.jsp").forward(request, response);
		}else {
			request.setAttribute("error", "Delete Fail!!");			
			request.getRequestDispatcher("USR002.jsp").forward(request, response);
		}
		//request.setAttribute("deleted","successful deleted!!");
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

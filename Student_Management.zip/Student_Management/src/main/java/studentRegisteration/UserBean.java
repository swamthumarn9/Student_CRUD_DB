package studentRegisteration;

import java.io.Serializable;

public class UserBean implements Serializable {
	String userID;
	String userName;
	String userPassword;
	String userConfirmPassword;
	String userRole;
	
	

	public String getUserID() {
		return userID;
	}
	
	public void setUserID(String userID) {
	this.userID = userID;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserConfirmPassword() {
		return userConfirmPassword;
	}
	public void setUserConfirmPassword(String userConfirmPassword) {
		this.userConfirmPassword = userConfirmPassword;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	
}

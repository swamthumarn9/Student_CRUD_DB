package studentRegisteration;

import java.io.Serializable;

public class CourseBean implements Serializable{
	
	String courseID;
	String courseName;
	
	
	public CourseBean(String courseID, String courseName) {
		super();
		this.courseID = courseID;
		this.courseName = courseName;
	}
	public CourseBean() {
		// TODO Auto-generated constructor stub
	}
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	@Override
	public String toString() {
		return "CourseBean [courseID=" + courseID + ", courseName=" + courseName + "]";
	}
	
	
}

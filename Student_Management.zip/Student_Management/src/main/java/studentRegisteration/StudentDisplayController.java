package studentRegisteration;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentmanagement.persistant.dao.StudentDAO;
import studentmanagement.persistant.dao.UserDAO;
import studentmanagement.persistant.dto.StudentResponseDTO;
import studentmanagement.persistant.dto.UserResponseDTO;

/**
 * Servlet implementation class StudentDisplayController
 */
@WebServlet("/StudentDisplayController")
public class StudentDisplayController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentDisplayController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentDAO studentdao=new StudentDAO();
		ArrayList<StudentResponseDTO> studentlist=studentdao.selectAll();
		request.setAttribute("studentlist", studentlist);
		request.getRequestDispatcher("STU003.jsp").forward(request, response);
		//response.sendRedirect("UserSearchController");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

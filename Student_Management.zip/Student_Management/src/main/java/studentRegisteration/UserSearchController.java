package studentRegisteration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentmanagement.persistant.dao.UserDAO;
import studentmanagement.persistant.dto.UserResponseDTO;


/**
 * Servlet implementation class UserSearchController
 */
@WebServlet("/UserSearchController")
public class UserSearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserSearchController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = (String)request.getParameter("userid");
		String name = (String)request.getParameter("username");
		//List<UserBean> userlist=(List<UserBean>) request.getServletContext().getAttribute("userlist");
		UserDAO userdao=new UserDAO();
		
		ArrayList<UserResponseDTO> userlist=userdao.showUserData();
		ArrayList<UserResponseDTO> searchlist =userdao.showUserData();
		
		if(id.isBlank()&&name.isBlank()) {
			request.setAttribute("userlist", userlist);
			request.getRequestDispatcher("USR003.jsp").include(request, response);
		}else {
			Iterator<UserResponseDTO> itr=userlist.iterator();
		while(itr.hasNext()) {
			UserResponseDTO user=itr.next();
			if(user.getUserId().equals(id)|| user.getUserName().equals(name)){
				searchlist.add(user);
			}
			request.setAttribute("userlist", searchlist);	
		}
		request.getRequestDispatcher("USR003.jsp").forward(request, response);
		}
		
	}

}

package studentRegisteration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentmanagement.persistant.dao.UserDAO;
import studentmanagement.persistant.dto.UserRequestDTO;
import studentmanagement.persistant.dto.UserResponseDTO;

/**
 * Servlet implementation class UserUpdateController
 */
@WebServlet("/UserUpdateController")
public class UserUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	//private static AtomicInteger autoUserId=new AtomicInteger(00);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserUpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserId(request.getParameter("userId"));
		UserDAO userdao=new UserDAO();
		UserResponseDTO res=userdao.selectOne(dto);
		request.setAttribute("res", res);
		request.getRequestDispatcher("USR002.jsp").forward(request, response);
	}

	/**
	 * @param updateUser 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		//int userid=autoUserId.getAndIncrement();
		//String userIdString="USR"+String.format("%03d", userid+1);
		//request.getServletContext().setAttribute("userIdString", userid);
		request.getServletContext().getAttribute("userIdString");
		
		UserBean userBean=new UserBean();
		String userID=(String) request.getServletContext().getAttribute("userIdString");
		userBean.setUserID(userID);
		userBean.setUserName(request.getParameter("userName"));
		userBean.setUserPassword(request.getParameter("userPassword"));
		userBean.setUserConfirmPassword(request.getParameter("userConfirmPassword"));
		userBean.setUserRole(request.getParameter("userRole"));
		
		
		if(userBean.getUserName	().equals("")|| userBean.getUserPassword().equals("")||userBean.getUserConfirmPassword().equals("")||
			userBean.getUserRole().equals("")) {
				request.setAttribute("error", "Fill Blanks!!");
				request.setAttribute("userbean", userBean);
				request.getRequestDispatcher("USR002.jsp").forward(request, response);
				}else {
					UserDAO userdao=new UserDAO();
					UserRequestDTO dto=new UserRequestDTO();
					dto.setUserId(userBean.getUserID());
					dto.setUserName(userBean.getUserName());
					dto.setPassword(userBean.getUserPassword());
					dto.setConfirmPassword(userBean.getUserConfirmPassword());
					dto.setUserRole(userBean.getUserRole());
					int i=userdao.updateUser(dto);
					if(i>0) {
						request.setAttribute("success", "Successful Updated!");
						request.getRequestDispatcher("USR002.jsp").forward(request, response);
					}else {
						request.setAttribute("error", "Update Fail!!");
						request.setAttribute("userbean", userBean);
						request.getRequestDispatcher("USR002.jsp").forward(request, response);
					}
					
					//response.sendRedirect("UserDisplayController");
				}
		}


}

package studentRegisteration;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentmanagement.persistant.dao.CourseDAO;
import studentmanagement.persistant.dto.CourseRequestDTO;


/**
 * Servlet implementation class CourseRegisterController
 */
@WebServlet("/CourseRegisterController")
public class CourseRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static AtomicInteger autoCourseId=new AtomicInteger(00);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CourseRegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//int courseId=autoCourseId.getAndIncrement();
		
		
		CourseBean cbean = new CourseBean();
		int courseId=autoCourseId.getAndIncrement();
		String courseIdString="COU"+String.format("%03d", courseId+1);
		cbean.setCourseID(request.getParameter("courseid"));
		cbean.setCourseName(request.getParameter("coursename"));
		
		if (cbean.getCourseName().equals("")) {
			request.setAttribute("error", "Fill the blank !!");
			request.setAttribute("cbean", cbean);
			request.getRequestDispatcher("BUD003.jsp").include(request, response);
		} else {		
			
			CourseDAO coursedao=new CourseDAO();
			CourseRequestDTO coursedto=new CourseRequestDTO();
			request.getServletContext().setAttribute("courseIdString", courseIdString);
			
			coursedto.setCourseId(cbean.getCourseID());
			coursedto.setCourseName(cbean.getCourseName());
			int i= coursedao.insertCourse(coursedto);
			
			//response.sendRedirect("UserDisplayController");
			if(i>0) {
				request.setAttribute("success", "Successful Register!");
				request.getRequestDispatcher("BUD003.jsp").forward(request, response);
			}else {
				request.setAttribute("error", "Insert Fail!!");
				request.setAttribute("coursebean", cbean);
				request.getRequestDispatcher("BUD003.jsp").forward(request, response);
			}
		}
	}

}

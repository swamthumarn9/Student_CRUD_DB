package studentRegisteration;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentUpdateController
 */
@WebServlet("/StudentUpdateController")
public class StudentUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static AtomicInteger autoStudentId=new AtomicInteger(00);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentUpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();	
		
		String StudentId=(String) request.getServletContext().getAttribute("studentIdString");
		
		StudentBean student=new StudentBean();
		student.setId(StudentId);
		student.setSname(request.getParameter("sname"));		
		student.setDob(request.getParameter("dob"));		
		student.setGender(request.getParameter("gender"));		
		student.setPhone(request.getParameter("phone"));		
		student.setEducation(request.getParameter("education"));
		String[] attend=request.getParameterValues("gridRadios");
		student.setAttend(attend);
		
		if(student.getSname().equals("")|| student.getDob().equals("")||student.getGender().equals("")||
				student.getPhone().equals("")||student.getEducation().equals("")) {
			request.setAttribute("error", "Fill Blanks!!");
			request.setAttribute("student", student);
			request.getRequestDispatcher("STU002.jsp").forward(request, response);
		}else {
			List<StudentBean> studentDetail=(List<StudentBean>) request.getServletContext().getAttribute("studentdetail");
			if(studentDetail==null) {
				studentDetail=new ArrayList();
			}
			studentDetail.add(student);
			request.setAttribute("success", "Successful Student Update!!");		
			request.getServletContext().setAttribute("studentdetail", studentDetail);
			request.getRequestDispatcher("STU002.jsp").forward(request, response);
			
			
		}
	}
	

}

package studentRegisteration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentmanagement.persistant.dao.CourseDAO;
import studentmanagement.persistant.dao.StudentDAO;
import studentmanagement.persistant.dto.CourseRequestDTO;
import studentmanagement.persistant.dto.CourseResponseDTO;
import studentmanagement.persistant.dto.StudentRequestDTO;
import studentmanagement.persistant.dto.StudentResponseDTO;

/**
 * Servlet implementation class StudetnSearchController
 */
@WebServlet("/StudentSearchController")
public class StudentSearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentSearchController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CourseDAO coursedao=new CourseDAO();
		ArrayList<CourseResponseDTO> courselist=new ArrayList();
		
		request.setAttribute("courselist", courselist);
		//CourseRequestDTO coursedto=new CourseRequestDTO();
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unlikely-arg-type")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sId = (String)request.getParameter("id");
		String sName = (String)request.getParameter("name");
		String sCourse = (String)request.getParameter("course");
		
		StudentDAO studentdao=new StudentDAO();
		
		ArrayList<StudentResponseDTO> studentlist=studentdao.showStudentData();
		ArrayList<ArrayList<CourseResponseDTO>> courseslist = new ArrayList<>();
		
		ArrayList<StudentResponseDTO> searchlist =studentdao.showStudentData();
		CourseDAO coursedao=new CourseDAO();
		
		//CourseRequestDTO coursedto=new CourseRequestDTO();
		//CourseResponseDTO selectOne = coursedao.selectOne(coursedto);		
		
		if(sId.isBlank() && sName.isBlank() && sCourse.isBlank()) {
			request.setAttribute("studentlist", studentlist);
			request.getRequestDispatcher("STU003.jsp").include(request, response);
			
			
			
		}else {
			Iterator<StudentResponseDTO> itr=studentlist.iterator();
		while(itr.hasNext()) {
			StudentResponseDTO student=itr.next();
			if(student.getStudentId().equals(sId)|| student.getStudentName().equals(sName)|| 
					student.getCourse().equals(sCourse)){
				searchlist.add(student);
			}
			request.setAttribute("studentlist", searchlist);	
		}
		request.getRequestDispatcher("STU003.jsp").forward(request, response);
		}
		
	}
}

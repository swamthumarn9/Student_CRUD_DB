package studentmanagement.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import studentmanagement.persistant.dto.UserRequestDTO;
import studentmanagement.persistant.dto.UserResponseDTO;

public class UserDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	public int insertUser(UserRequestDTO userdto) {
		int result=0;
		String sql="insert into users (user_id, user_name, user_password, "
				+ "user_confirmpassword, user_role) values (?,?,?,?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, userdto.getUserId());
			ps.setString(2, userdto.getUserName());
			ps.setString(3, userdto.getPassword());
			ps.setString(4, userdto.getConfirmPassword());
			ps.setString(5, userdto.getUserRole());
			result=ps.executeUpdate();
			System.out.println(result);
		} catch (SQLException e) {
			System.out.println("Database Error!");
		}
		return result;
	}
	
	public int updateUser(UserRequestDTO userdto) {
		int result=0;
		String sql="update users set user_name=?, user_password=?, user_confirmpassword=?, user_role=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, userdto.getUserName());
			ps.setString(2, userdto.getPassword());
			ps.setString(3, userdto.getConfirmPassword());
			ps.setString(4, userdto.getUserRole());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database Error!");
		}
		return result;
	}
	
	public int deleteUser(UserRequestDTO userdto) {
		int result=0;
		String sql="delete from users where user_id=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, userdto.getUserId());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database Error!");
		}
		return result;
	}
	
	public UserResponseDTO selectOne(UserRequestDTO userdto) {
		UserResponseDTO res=new UserResponseDTO();
		String sql="select * from users where user_id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, userdto.getUserId());
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				res.setUserId(rs.getString("user_id"));
				res.setUserName(rs.getString("user_name"));
				res.setPassword(rs.getString("user_password"));
				res.setConfirmPassword(rs.getString("user_confirmpassword"));
			}
		} catch (SQLException e) {
			System.out.println("Database Error!");
		}
		return res;
	}
	
	public ArrayList<UserResponseDTO> showUserData(){
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ArrayList<UserResponseDTO> userlist=new ArrayList();
		String sql="select user_id, user_name, user_role from users";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				UserResponseDTO res=new UserResponseDTO();
				res.setUserId(rs.getString("user_id"));
				res.setUserName(rs.getString("user_name"));
				res.setUserRole(rs.getString("user_role"));
				userlist.add(res);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userlist;
	}
	
	
	public ArrayList<UserResponseDTO> selectAll(){
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ArrayList<UserResponseDTO> userlist=new ArrayList();
		String sql="select * from users";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				UserResponseDTO res=new UserResponseDTO();
				res.setUserId(rs.getString("user_id"));
				res.setUserName(rs.getString("user_name"));
				res.setPassword(rs.getString("user_password"));
				res.setConfirmPassword(rs.getString("user_confirmpassword"));
				res.setUserRole(rs.getString("user_role"));
				userlist.add(res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userlist;
	}
}

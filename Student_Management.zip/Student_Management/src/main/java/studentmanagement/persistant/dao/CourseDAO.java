package studentmanagement.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import studentmanagement.persistant.dto.CourseRequestDTO;
import studentmanagement.persistant.dto.CourseResponseDTO;

public class CourseDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	public int insertCourse(CourseRequestDTO coursedto) {
		int result=0;
		String sql="insert into courses (course_id, course_name) values (?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, coursedto.getCourseId());
			ps.setString(2, coursedto.getCourseName());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Database Error!"+e.getMessage());
		}
		return result;
	}
	
	
	
	public ArrayList<CourseResponseDTO> selectCourseListbyStudentId(String studentId) {
		CourseResponseDTO res=new CourseResponseDTO();
		ArrayList<CourseResponseDTO> courselist=new ArrayList<CourseResponseDTO>();
		String sql="select courses.course_name, courses.course_id from student_course join courses "
				+ "on student_course.course where student_id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, studentId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				res.setCourseId(rs.getString("course_id"));
				res.setCourseName(rs.getString("course_name"));
				courselist.add(res);
			}
		} catch (SQLException e) {
			System.out.println("Database Error!");
		}
		return courselist;
	}
	
	
	public ArrayList<CourseResponseDTO> selectAll(){
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ArrayList<CourseResponseDTO> courselist=new ArrayList();
		String sql="select * from courses";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				CourseResponseDTO res=new CourseResponseDTO();
				res.setCourseId(rs.getString("course_id"));
				res.setCourseName(rs.getString("course_name"));
				courselist.add(res);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return courselist;
	}
	
	
	public int insertID(String StudentId, String courseId ) {
		int result=0;
		String sql="insert into student_course (student_id, course_id) values (?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, StudentId);
			ps.setString(2, courseId);
			result=ps.executeUpdate();
			System.out.println(result);
		} catch (SQLException e) {
			System.out.println("Database Error!"+e.getMessage());
		}
		return result;
	}
}
